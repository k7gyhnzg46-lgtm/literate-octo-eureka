CREATE TABLE account_plans (
  user_id TEXT PRIMARY KEY NOT NULL,
  plan TEXT NOT NULL,
  revision INTEGER NOT NULL
);
