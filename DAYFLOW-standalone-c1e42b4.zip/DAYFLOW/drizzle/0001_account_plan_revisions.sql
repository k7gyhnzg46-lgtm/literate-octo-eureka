CREATE TABLE account_plan_revisions (
  user_id TEXT NOT NULL,
  revision INTEGER NOT NULL,
  plan TEXT NOT NULL,
  saved_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (user_id, revision)
);
INSERT INTO account_plan_revisions (user_id, revision, plan)
SELECT user_id, revision, plan FROM account_plans;
CREATE TRIGGER archive_account_plan_revision
BEFORE UPDATE OF plan ON account_plans
BEGIN
  INSERT OR IGNORE INTO account_plan_revisions (user_id, revision, plan)
  VALUES (OLD.user_id, OLD.revision, OLD.plan);
END;
