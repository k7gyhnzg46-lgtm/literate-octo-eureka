CREATE VIEW account_event_types AS
SELECT account.user_id,
       json_extract(event_type.value, '$.id') AS id,
       json_extract(event_type.value, '$.name') AS name,
       json_extract(event_type.value, '$.color') AS color,
       json_extract(event_type.value, '$.icon') AS icon,
       json_extract(event_type.value, '$.archived') AS archived
FROM account_plans AS account, json_each(account.plan, '$.types') AS event_type;
