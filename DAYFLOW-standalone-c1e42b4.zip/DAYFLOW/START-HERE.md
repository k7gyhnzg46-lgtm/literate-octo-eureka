# DAYFLOW 日序 · 独立部署快速开始

本包基于源码提交 `c1e42b4`，内含已经构建的独立应用入口 `dist/server/standalone.mjs`。独立版使用 Cloudflare Workers、D1 和 Auth0。打开站点后，用户通过 Auth0 注册或登录。

## 文件入口

| 文件 | 用途 |
| --- | --- |
| `dist/index.html`、`dist/style.css`、`dist/app.js` | 页面、样式与交互源码 |
| `worker/index.mjs`、`worker/standalone.mjs` | 计划数据接口和独立站认证源码 |
| `dist/server/standalone.mjs` | Cloudflare Workers 部署入口，已打包页面和接口 |
| `drizzle/` | D1 数据库迁移 |
| `wrangler.example.toml` | Cloudflare 部署配置模板 |

## 构建和测试

安装 Node.js 24 或更新版本后，在解压出来的 DAYFLOW 文件夹打开终端。

```sh
npm run build
node --test --test-isolation=none test/dayflow.test.mjs
```

构建不需要安装项目依赖。浏览器需要从 Worker 打开应用，这样页面才能调用账户和数据接口。

## 部署到你自己的 Cloudflare 账号

1. 将 `wrangler.example.toml` 复制为 `wrangler.toml`。安装好 Node.js 后，可用 `npx wrangler login` 登录 Cloudflare，再用 `npx wrangler d1 create dayflow` 创建数据库。将输出的数据库 ID 填到 `database_id`，绑定名保留 `DB`。
2. 将 `APP_ORIGIN` 改为计划使用的真实 HTTPS 站点原点，例如 Worker 的 `workers.dev` 地址，末尾不带斜杠。
3. 在 Auth0 创建 Regular Web Application，启用允许注册的数据库连接。填入 `AUTH0_DOMAIN`（纯域名）和 `AUTH0_CLIENT_ID`。将 Allowed Callback URLs 设为你的站点原点加 `/auth/callback`，Allowed Logout URLs 设为站点原点加 `/`。令牌端点客户端认证方式使用 Client Secret (Post)。
4. 在项目目录执行以下命令，创建数据库表并部署。

   ```sh
   npx wrangler d1 migrations apply DB --remote
   npx wrangler deploy
   npx wrangler secret put AUTH0_CLIENT_SECRET
   ```

   最后一条命令会提示输入 Auth0 Client Secret。把密钥存为 Worker Secret，项目文件和压缩包中只保留公开配置。
5. 打开部署返回的网址，用两个测试账户验证注册、登录、日程保存、数据隔离和退出。用手机和电脑分别验证滚轮。完成这些检查后再邀请他人使用。

包中不含现网数据。若要迁移个人旧记录，在旧站登录后将同站点的 `/api/plan` 响应保存为 JSON，再从独立站的空账户使用「导入账户备份」。生产切换和旧库备份的细节见 [README.md](README.md)。
