import assert from 'node:assert/strict';
import {readFileSync, readdirSync} from 'node:fs';
import {DatabaseSync} from 'node:sqlite';
import test from 'node:test';
import vm from 'node:vm';
import sites from '../dist/server/index.js';
import standalone from '../dist/server/standalone.mjs';

const oldPlan = {
  days: {'2026-11-25': [{id:'one', title:'阅读', start:'22:00', end:'24:00', category:'study'}]},
  templates: [],
  goals: [{id:'habit',title:'每日阅读',start:'2026-11-25',end:'2027-02-24',checks:['2026-11-25']}]
};
function browserModel(){
  const elements=new Map(), noop=()=>{};
  const get=id=>{
    if(!elements.has(id)) elements.set(id,{showModal:noop,close:noop});
    return elements.get(id);
  };
  const model=vm.createContext({assert,oldPlan,document:{getElementById:get,querySelectorAll:()=>[],addEventListener:noop},
    window:{addEventListener:noop},localStorage:{getItem:noop},fetch:()=>new Promise(()=>{})});
  vm.runInContext(readFileSync('dist/app.js','utf8'),model);
  return model;
}
function database(){
  const db=new DatabaseSync(':memory:');
  const migrations=readdirSync('drizzle').filter(file=>file.endsWith('.sql')).sort();
  db.exec(readFileSync('drizzle/'+migrations.shift(),'utf8'));
  db.prepare('INSERT INTO account_plans VALUES(?,?,?)').run('owner',JSON.stringify(oldPlan),1);
  for(const file of migrations) db.exec(readFileSync('drizzle/'+file,'utf8'));
  return {db,env:{DB:{prepare(sql){
    return {bind(...args){
      const statement=db.prepare(sql);
      return {first:()=>statement.get(...args),all:()=>({results:statement.all(...args)}),run:()=>({meta:statement.run(...args)})};
    }};
  }}}};
}
const origin='https://dayflow.example';
function request(path, user, method='GET', body, headers={}){
  return new Request(origin+path,{method,headers:{origin,'content-type':'application/json',
    ...(user?{'oai-authenticated-user-id':user}:{}),...headers},body:body===undefined?undefined:JSON.stringify(body)});
}

test('旧历史、按日分段、相邻事件与实际重叠',()=>{
  const model=browserModel();
  vm.runInContext(`
    state=upgradePlan(oldPlan);
    assert.equal(state.events[0].endAt,'2026-11-26T00:00');
    assert.equal(state.goals[0].checks[0],'2026-11-25');
    assert.equal(state.goals[0].category,'uncategorized');
    state.events[0].endAt='2026-11-27T07:30';
    assert.equal(fullDuration(state.events[0]),2010);
    selected='2026-11-25'; assert.equal(dayEvents()[0].start,'22:00'); assert.equal(dayEvents()[0].end,'24:00');
    selected='2026-11-26'; assert.equal(dayEvents()[0].start,'00:00'); assert.equal(dayEvents()[0].end,'24:00');
    selected='2026-11-27'; assert.equal(dayEvents()[0].end,'07:30');
    assert.equal(dayEvents()[0].id,'one');
    assert.equal(overlap(state.events[0],{startAt:'2026-11-27T07:30',endAt:'2026-11-27T08:00'}),false);
    assert.equal(overlap(state.events[0],{startAt:'2026-11-26T07:30',endAt:'2026-11-26T08:00'}),true);
  `,model);
});

test('统一时间组件与归档类型兼容',()=>{
  vm.runInContext(`
    state=upgradePlan(oldPlan);
    assert.match(timeWheel('开始时间','start','23:59'),/value="59" selected/);
    assert.match(timeWheel('结束时间','end','00:00'),/name="endHour"/);
    assert.equal(timeValue(new Map([['endHour','02'],['endMinute','30']]),'end'),'02:30');
    state.types=state.types.map(type=>type.id==='study'?{...type,name:'深度学习',archived:true}:type);
    assert.match(typePicker('study'),/深度学习（已归档）/);
    assert.doesNotMatch(typePicker('work'),/深度学习/);
    assert.equal(typeText(state.events[0].category),'📚 深度学习');
  `,browserModel());
});

test('真实 SQLite 上的日程保存、数据隔离、冲突和版本恢复',async()=>{
  const {db,env}=database();
  const api=(...args)=>sites.fetch(request(...args),env);
  const plan=vm.runInContext('upgradePlan(oldPlan)',browserModel());
  assert.deepEqual((await (await api('/api/plan','owner')).json()).plan,oldPlan);
  const invalid=structuredClone(plan);
  invalid.events[0].endAt=invalid.events[0].startAt;
  assert.equal((await api('/api/plan','owner','PUT',{revision:1,plan:invalid})).status,400);
  assert.equal((await api('/api/plan','owner','PUT',{revision:1,plan})).status,200);
  assert.equal((await api('/api/plan','owner','PUT',{revision:1,plan})).status,409);
  assert.equal(db.prepare('SELECT count(*) AS n FROM account_event_types WHERE user_id=?').get('owner').n,8);
  assert.equal((await api('/api/plan',null)).status,401);
  assert.deepEqual(await (await api('/api/plan','other')).json(),{plan:null,revision:0});
  assert.deepEqual(await (await api('/api/plan/revisions','other')).json(),[]);
  assert.equal((await api('/api/plan/revisions','other','POST',{revision:2,backup:1})).status,404);
  assert.equal((await api('/api/plan/revisions','owner','POST',{revision:2,backup:1})).status,200);
  assert.deepEqual(await (await api('/api/plan','owner')).json(),{plan:oldPlan,revision:3});
  assert.equal((await (await api('/api/plan/revisions','owner')).json()).length,2);
});

test('独立入口公开，伪造的 Sites 身份无效，注册跳转使用 PKCE',async()=>{
  const {env}=database();
  Object.assign(env,{APP_ORIGIN:origin,AUTH0_DOMAIN:'auth.example',AUTH0_CLIENT_ID:'test-client',AUTH0_CLIENT_SECRET:'test-secret'});
  const home=await standalone.fetch(request('/'),env);
  assert.match(await home.text(),/注册/);
  assert.equal((await standalone.fetch(request('/api/plan','owner'),env)).status,401);
  const signup=await standalone.fetch(request('/auth/register'),env);
  const location=new URL(signup.headers.get('location'));
  assert.equal(location.origin,'https://auth.example');
  assert.equal(location.searchParams.get('screen_hint'),'signup');
  assert.equal(location.searchParams.get('code_challenge_method'),'S256');
  assert.match(signup.headers.get('set-cookie'),/Secure; HttpOnly; SameSite=Lax/);
  const invalid=await standalone.fetch(request('/auth/callback?state=invalid&code=any'),env);
  assert.equal(invalid.headers.get('location'),'/');
});
