# DAYFLOW（日序）

日序保留纵向时间线、可缩放的 24 小时轮盘、工作日模板以及三个月目标。开发和验收使用 Node.js 24 或更新版本。

```sh
npm test
npm run build
```

## 改动与验收

| 功能 | 文件 | 验收 |
| --- | --- | --- |
| 滚轮选择 | `dist/app.js`、`dist/style.css` | 小时和分钟字段、预选值和组合格式通过测试。仍需在真实手机和桌面浏览器分别测试滑动、鼠标滚轮、键盘和辅助技术。 |
| 跨日期日程 | `dist/app.js`、`worker/index.mjs` | 旧 24:00 转换、三天分段、同一 ID、时长、重叠判断及服务端拒绝无效结束时间通过测试。模板保存跨天长度，套用时跳过重叠项目。 |
| 事件类型 | `dist/app.js`、`worker/index.mjs`、`drizzle/0003_account_event_types.sql` | 日程和目标共用账户内的类型 ID。旧目标关联到「未分类」，归档类型仍能显示在历史记录中。D1 视图按账户查询当前类型。 |
| 数据备份与恢复 | `worker/index.mjs`、`drizzle/0001_account_plan_revisions.sql` | SQLite 验证旧数据读取、用户隔离、并发版本检查、恢复以及恢复前的版本仍可读取。 |
| 独立站与身份认证 | `worker/standalone.mjs`、`drizzle/0002_standalone_sessions.sql`、`scripts/build-worker.mjs`、`wrangler.example.toml` | 自动测试覆盖公开入口、注册跳转、PKCE、无会话拒绝与忽略 Sites 身份头。真实 Auth0 注册、登录、回调、跨设备和退出仍需在预发布站验收。 |

日期与时间按用户输入的日历和钟面时间保存。时长按钟面时间计算，跨夏令时切换时可能与真实经过时间相差一小时。

## 独立部署与迁移

生产 Sites 的回退标签为 `dayflow-before-optimization`（`b703ecd`）。现网 D1 的 `account_plans` 仍使用旧版结构。先做生产数据库的受控导出，核对账户数和文件完整性，并在独立测试库验证恢复，再对生产库执行任何迁移。备份包含私人日程，保存在有访问控制的位置。候选 SQL 在迁移时保存当前计划版本，并在以后每次改动前以同一事务保存上一版本。

独立版使用 Cloudflare Worker、D1 与 Auth0 Universal Login。Sites 入口仍由原平台认证，独立入口只使用自身的服务端会话。

1. 在外部 Cloudflare 账户创建候选 Worker 和 D1 数据库。复制 `wrangler.example.toml` 为环境配置并填入真实数据库 ID、站点 HTTPS 原点、Auth0 域名和客户端 ID。
2. 在 Auth0 创建 Regular Web Application，开启你的注册连接和 Universal Login，设置对应的 `/auth/callback` 回调地址和根路径登出地址。用 Worker secret 配置 `AUTH0_CLIENT_SECRET`。把 Auth0 的防暴力登录和异常注册保护打开。
3. 运行 `npm test`，先向预发布数据库依次应用 `drizzle/` 的迁移，再部署 `dist/server/standalone.mjs`。验收注册、登录、退出、跨设备读取、两个真实账户隔离、备份恢复和真实设备滚轮交互。
4. 在原网站登录后，可将本账户的 `/api/plan` 响应保存为 JSON。登录独立站空账户后，用「导入账户备份」将文件导入当前账户。Sites 和 Auth0 的用户 ID 属于不同命名空间，迁移不通过邮箱自动认领数据。若要批量迁移，先取得每个账户的已验证身份映射。
5. 全部验收通过后再切换生产。公开根路径提供登录、注册和站点说明，个人数据接口禁止缓存且要求登录。绑定自定义域名时同步更新 Worker 的 `APP_ORIGIN` 以及 Auth0 的回调和登出地址。
