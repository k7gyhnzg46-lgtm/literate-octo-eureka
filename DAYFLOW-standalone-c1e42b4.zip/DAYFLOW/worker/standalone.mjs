// Auth0 handles registration, credential verification, and password recovery.
const sessionCookie = '__Host-dayflow_session';
const flowCookie = '__Host-dayflow_flow';
const sessionAge = 60*60*24*7;
const flowAge = 600;
const safeHeaders = {'Cache-Control':'private, no-store','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer'};

function encode(bytes) {
  return btoa(String.fromCharCode(...bytes)).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
}
const random = () => encode(crypto.getRandomValues(new Uint8Array(32)));
const digest = async value => encode(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(value))));
const cookie = (name,value,age) => name+'='+value+'; Path=/; Secure; HttpOnly; SameSite=Lax; Max-Age='+age;
function readCookie(request,name) {
  const entry=(request.headers.get('Cookie') ?? '').split(';').map(part=>part.trim()).find(part=>part.startsWith(name+'='));
  return entry?.slice(name.length+1);
}
function redirect(target, cookies=[]) {
  const headers=new Headers({...safeHeaders,Location:target});
  for(const value of cookies) headers.append('Set-Cookie',value);
  return new Response(null,{status:303,headers});
}
function signedOut() {
  return new Response('<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><meta name="description" content="日序 DAYFLOW，每日时间管理与目标打卡"><title>DAYFLOW 日序</title><link rel="stylesheet" href="/style.css"><main><section class="hero"><div><h1>DAYFLOW 日序</h1><p>规划每天的时间，记录长期目标。</p></div></section><section class="panel"><h2>进入个人空间</h2><div class="actions"><a href="/auth/login">登录</a><a href="/auth/register">注册</a></div></section></main></html>',{headers:{...safeHeaders,'Content-Type':'text/html; charset=utf-8'}});
}
function configuration(env) {
  if (!env.APP_ORIGIN || !env.AUTH0_DOMAIN || !env.AUTH0_CLIENT_ID || !env.AUTH0_CLIENT_SECRET) return null;
  const origin=new URL(env.APP_ORIGIN);
  if(origin.protocol!=='https:' || origin.origin!==env.APP_ORIGIN || !/^[a-z0-9.-]+$/i.test(env.AUTH0_DOMAIN)) return null;
  return {origin:origin.origin,issuer:'https://'+env.AUTH0_DOMAIN,clientId:env.AUTH0_CLIENT_ID,secret:env.AUTH0_CLIENT_SECRET,
    callback:origin.origin+'/auth/callback'};
}
async function standalone(request,env) {
  const config=configuration(env);
  const url=new URL(request.url);
  if(!config) return new Response('DAYFLOW authentication is not configured',{status:503,headers:safeHeaders});
  if(url.origin!==config.origin) return new Response('Invalid host',{status:421,headers:safeHeaders});
  const {pathname}=url;
  if((pathname==='/auth/login' || pathname==='/auth/register') && request.method==='GET'){
    const state=random(), verifier=random();
    const params=new URLSearchParams({response_type:'code',client_id:config.clientId,redirect_uri:config.callback,
      scope:'openid',state,code_challenge:await digest(verifier),code_challenge_method:'S256'});
    if(pathname==='/auth/register') params.set('screen_hint','signup');
    return redirect(config.issuer+'/authorize?'+params,[cookie(flowCookie,state+'.'+verifier,flowAge)]);
  }
  if(pathname==='/auth/callback' && request.method==='GET'){
    const [state,verifier]=(readCookie(request,flowCookie) ?? '').split('.');
    const code=url.searchParams.get('code');
    const clearFlow=cookie(flowCookie,'',0);
    if(!state || !verifier || url.searchParams.get('state')!==state || !code) return redirect('/',[clearFlow]);
    const token=await fetch(config.issuer+'/oauth/token',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},
      body:new URLSearchParams({grant_type:'authorization_code',client_id:config.clientId,client_secret:config.secret,
        redirect_uri:config.callback,code_verifier:verifier,code})});
    if(!token.ok) return redirect('/',[clearFlow]);
    const {access_token:accessToken}=await token.json();
    if(!accessToken) return redirect('/',[clearFlow]);
    const info=await fetch(config.issuer+'/userinfo',{headers:{Authorization:'Bearer '+accessToken}});
    if(!info.ok) return redirect('/',[clearFlow]);
    const {sub}=await info.json();
    if(typeof sub!=='string' || !sub || sub.length>255) return redirect('/',[clearFlow]);
    const session=random();
    const hash=await digest(session);
    const now=Math.floor(Date.now()/1000);
    const user='oidc:'+await digest(config.issuer+'\n'+sub);
    const prior=readCookie(request,sessionCookie);
    await env.DB.batch([
      env.DB.prepare('DELETE FROM auth_sessions WHERE expires_at <= ? OR token_hash = ?').bind(now,prior?await digest(prior):''),
      env.DB.prepare('INSERT INTO auth_sessions (token_hash,user_id,expires_at) VALUES (?,?,?)').bind(hash,user,now+sessionAge)
    ]);
    return redirect('/',[clearFlow,cookie(sessionCookie,session,sessionAge)]);
  }
  const session=readCookie(request,sessionCookie);
  const hash=session?await digest(session):null;
  if(pathname==='/auth/logout' && request.method==='POST'){
    if(request.headers.get('origin')!==config.origin) return new Response(null,{status:403,headers:safeHeaders});
    if(hash) await env.DB.prepare('DELETE FROM auth_sessions WHERE token_hash = ?').bind(hash).run();
    const params=new URLSearchParams({client_id:config.clientId,returnTo:config.origin+'/'});
    return redirect(config.issuer+'/v2/logout?'+params,[cookie(sessionCookie,'',0)]);
  }
  // Public visitors have access to the landing page and its stylesheet.
  if(pathname==='/style.css' && request.method==='GET'){
    return new Response(assets[pathname][1],{headers:{...safeHeaders,'Content-Type':'text/css; charset=utf-8'}});
  }
  const row=hash?await env.DB.prepare('SELECT user_id FROM auth_sessions WHERE token_hash = ? AND expires_at > ?')
    .bind(hash,Math.floor(Date.now()/1000)).first():null;
  if(!row && pathname==='/' && request.method==='GET') return signedOut();
  if(!row && !pathname.startsWith('/api/')) return new Response(null,{status:404,headers:safeHeaders});
  if(row && pathname==='/' && request.method==='GET'){
    const html=assets[pathname][1].replace('<button id="backups">','<form method="post" action="/auth/logout"><button>退出登录</button></form><button id="backups">');
    return new Response(html,{headers:{...safeHeaders,'Content-Type':'text/html; charset=utf-8'}});
  }
  return plannerRequest(request,env,row?.user_id);
}

export default {
  async fetch(request,env){
    try {return await standalone(request,env);}
    catch {return new Response('DAYFLOW unavailable',{status:503,headers:safeHeaders});}
  }
};
