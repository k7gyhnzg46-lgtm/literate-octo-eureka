const noStore = {'Cache-Control':'private, no-store','X-Content-Type-Options':'nosniff'};
const json = (value,status=200) => Response.json(value,{status,headers:noStore});
const isObject = value => value !== null && typeof value === 'object' && !Array.isArray(value);
const date = value => typeof value==='string' && /^\d{4}-\d{2}-\d{2}$/.test(value);
const time = /^(?:[01]\d|2[0-3]):[0-5]\d$/;
const text = value => typeof value==='string' && value.length>0 && value.length<=60;
const id = value => typeof value==='string' && /^[a-z0-9-]{1,60}$/i.test(value);
const color = value => typeof value==='string' && /^#[a-f0-9]{6}$/i.test(value);
const validStamp = value => typeof value==='string' && value.length===16 &&
  date(value.slice(0,10)) && value[10]==='T' && time.test(value.slice(11)) &&
  Number.isFinite(Date.parse(value+'Z')) && new Date(value+'Z').toISOString().slice(0,16)===value;
function validPlan(p) {
  if (!isObject(p)) return false;
  const types=p.types;
  if (!Array.isArray(types) || !types.some(t=>t && !t.archived) ||
      !types.every(t=>isObject(t) && id(t.id) && text(t.name) && color(t.color) &&
        typeof t.icon==='string' && t.icon.length>0 && t.icon.length<=16 && typeof t.archived==='boolean')) return false;
  const ids=new Set(types.map(t=>t.id));
  if (ids.size!==types.length) return false;
  const eventBase=e=>isObject(e) && id(e.id) && text(e.title) && ids.has(e.category);
  return Array.isArray(p.events) && new Set(p.events.map(e=>e?.id)).size===p.events.length &&
    p.events.every(e=>eventBase(e) && validStamp(e.startAt) && validStamp(e.endAt) && e.startAt<e.endAt) &&
    Array.isArray(p.templates) && p.templates.every(t=>isObject(t) && id(t.id) && text(t.title) &&
      Array.isArray(t.events) && t.events.every(e=>eventBase(e) && time.test(e.start) &&
        (time.test(e.end) || e.end==='24:00') &&
        (e.endOffset===undefined || (Number.isInteger(e.endOffset) && e.endOffset>=0 && e.endOffset<=3652059)) &&
        (e.endOffset>0 ? time.test(e.end) : e.start<e.end))) &&
    Array.isArray(p.goals) && p.goals.every(g=>isObject(g) && id(g.id) && text(g.title) &&
      (g.category===undefined || ids.has(g.category)) &&
      date(g.start) && date(g.end) && g.start<=g.end && Array.isArray(g.checks) &&
      new Set(g.checks).size===g.checks.length &&
      g.checks.every(d=>date(d) && g.start<=d && d<=g.end)) &&
    (p.layout===undefined || ['timeline','wheel'].includes(p.layout));
}
async function account(request,env,user) {
  if (!user) return json({error:'Sign-in required'},401);
  if (request.method==='GET') {
    const row=await env.DB.prepare('SELECT plan, revision FROM account_plans WHERE user_id = ?').bind(user).first();
    return json({plan:row ? JSON.parse(row.plan) : null,revision:row?.revision ?? 0});
  }
  if (request.method!=='PUT') return json({error:'Method not allowed'},405);
  if (request.headers.get('origin')!==new URL(request.url).origin) return json({error:'Invalid origin'},403);
  if (request.headers.get('content-type')!=='application/json') return json({error:'Expected JSON'},415);
  let data;
  try {
    const body=await request.text();
    if (new TextEncoder().encode(body).length>750000) return json({error:'Plan is too large'},413);
    data=JSON.parse(body);
  } catch {return json({error:'Invalid JSON'},400);}
  const {plan,revision} = data ?? {};
  if (!Number.isSafeInteger(revision) || revision<0 || !validPlan(plan)) return json({error:'Invalid plan'},400);
  const contents=JSON.stringify(plan);
  const result=revision===0
    ? await env.DB.prepare('INSERT INTO account_plans (user_id, plan, revision) VALUES (?, ?, 1) ON CONFLICT(user_id) DO NOTHING').bind(user,contents).run()
    : await env.DB.prepare('UPDATE account_plans SET plan = ?, revision = revision + 1 WHERE user_id = ? AND revision = ?').bind(contents,user,revision).run();
  if (!result.meta.changes) return json({error:'Plan changed'},409);
  return json({revision:revision+1});
}
async function revisions(request,env,user) {
  if (!user) return json({error:'Sign-in required'},401);
  if (request.method==='GET') {
    const rows=await env.DB.prepare('SELECT revision, saved_at FROM account_plan_revisions WHERE user_id = ? ORDER BY revision DESC LIMIT 50').bind(user).all();
    return json(rows.results);
  }
  if (request.method!=='POST') return json({error:'Method not allowed'},405);
  if (request.headers.get('origin')!==new URL(request.url).origin) return json({error:'Invalid origin'},403);
  let data;
  try {data=await request.json();} catch {return json({error:'Invalid JSON'},400);}
  if (!Number.isSafeInteger(data?.revision) || !Number.isSafeInteger(data?.backup)) return json({error:'Invalid revision'},400);
  const previous=await env.DB.prepare('SELECT plan FROM account_plan_revisions WHERE user_id = ? AND revision = ?').bind(user,data.backup).first();
  if (!previous) return json({error:'Backup not found'},404);
  const result=await env.DB.prepare('UPDATE account_plans SET plan = ?, revision = revision + 1 WHERE user_id = ? AND revision = ?')
    .bind(previous.plan,user,data.revision).run();
  return result.meta.changes ? json({revision:data.revision+1}) : json({error:'Plan changed'},409);
}
async function plannerRequest(request,env,user) {
  const path=new URL(request.url).pathname;
  if(path==='/api/plan' || path==='/api/plan/revisions'){
    try {return await (path==='/api/plan'?account:revisions)(request,env,user);}
    catch {return json({error:'Account storage unavailable'},503);}
  }
  if (!user) return new Response('Sign-in required',{status:401,headers:noStore});
  if (!Object.hasOwn(assets,path)) return new Response('Not found',{status:404,headers:noStore});
  const [type,body]=assets[path];
  return new Response(body,{headers:{...noStore,'Content-Type':type+'; charset=utf-8'}});
}
// BEGIN SITES ENTRY
export default {
  fetch(request,env) {
    return plannerRequest(request,env,request.headers.get('oai-authenticated-user-id'));
  }
};
