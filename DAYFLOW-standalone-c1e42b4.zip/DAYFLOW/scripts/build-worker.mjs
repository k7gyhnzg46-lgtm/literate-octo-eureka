import {mkdir, readFile, writeFile, copyFile} from 'node:fs/promises';

const entries = [
  ['/', 'text/html', 'dist/index.html'],
  ['/style.css', 'text/css', 'dist/style.css'],
  ['/app.js', 'application/javascript', 'dist/app.js'],
];
const assets = Object.fromEntries(await Promise.all(entries.map(async ([route, type, file]) =>
  [route, [type, await readFile(file, 'utf8')]]
)));
await mkdir('dist/server', {recursive: true});
await mkdir('dist/.openai', {recursive: true});
const worker = await readFile('worker/index.mjs', 'utf8');
await writeFile('dist/server/index.js', worker + '\nconst assets = ' + JSON.stringify(assets) + ';\n');
await copyFile('.openai/hosting.json', 'dist/.openai/hosting.json');

const standalone = await readFile('worker/standalone.mjs', 'utf8');
await writeFile('dist/server/standalone.mjs', worker.split('// BEGIN SITES ENTRY')[0] +
  '\nconst assets = ' + JSON.stringify(assets) + ';\n' + standalone);
